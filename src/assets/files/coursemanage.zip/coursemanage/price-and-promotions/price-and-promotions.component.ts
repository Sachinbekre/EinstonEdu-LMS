import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-price-and-promotions',
  templateUrl: './price-and-promotions.component.html',
  styleUrls: ['./price-and-promotions.component.scss']
})
export class PriceAndPromotionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
