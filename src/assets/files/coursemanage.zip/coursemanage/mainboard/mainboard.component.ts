import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainboard',
  templateUrl: './mainboard.component.html',
  styleUrls: ['./mainboard.component.scss']
})
export class MainboardComponent implements OnInit {
  basicsData ;
  captionData;
  communicationData;
  coursestrData ;
  curriculumData;
  filmData;
  goalsData ;
  pricepromoData;
  setupData;
  constructor() { }

  ngOnInit() {
  }
  goals(){
    this.basicsData =false;
    this.captionData=false;
    this.communicationData=false;
    this.coursestrData=false;
    this.curriculumData=false;
    this.filmData=false;
    this.goalsData=true;
    this.pricepromoData=false;
    this.setupData=false;
  }
  basics(){
    this.basicsData =true;
    this.captionData=false;
    this.communicationData=false;
    this.coursestrData=false;
    this.curriculumData=false;
    this.filmData=false;
    this.goalsData=false;
    this.pricepromoData=false;
    this.setupData=false;
  }
  caption(){
    this.basicsData =false;
    this.captionData=true;
    this.communicationData=false;
    this.coursestrData=false;
    this.curriculumData=false;
    this.filmData=false;
    this.goalsData=false;
    this.pricepromoData=false;
    this.setupData=false;
  }
  communication(){
    this.basicsData =false;
    this.captionData=false;
    this.communicationData=true;
    this.coursestrData=false;
    this.curriculumData=false;
    this.filmData=false;
    this.goalsData=false;
    this.pricepromoData=false;
    this.setupData=false;
  }
  coursestr(){
    this.basicsData =false;
    this.captionData=false;
    this.communicationData=false;
    this.coursestrData=true;
    this.curriculumData=false;
    this.filmData=false;
    this.goalsData=false;
    this.pricepromoData=false;
    this.setupData=false;
  }
  curriculum(){
    this.basicsData =false;
    this.captionData=false;
    this.communicationData=false;
    this.coursestrData=false;
    this.curriculumData=true;
    this.filmData=false;
    this.goalsData=false;
    this.pricepromoData=false;
    this.setupData=false;
  }
  film(){
    this.basicsData =false;
    this.captionData=false;
    this.communicationData=false;
    this.coursestrData=false;
    this.curriculumData=false;
    this.filmData=true;
    this.goalsData=false;
    this.pricepromoData=false;
    this.setupData=false;
  }
  pricepromo(){
    this.basicsData =false;
    this.captionData=false;
    this.communicationData=false;
    this.coursestrData=false;
    this.curriculumData=false;
    this.filmData=false;
    this.goalsData=false;
    this.pricepromoData=true;
    this.setupData=false;
  }
  setup(){
    this.basicsData =false;
    this.captionData=false;
    this.communicationData=false;
    this.coursestrData=false;
    this.curriculumData=false;
    this.filmData=false;
    this.goalsData=false;
    this.pricepromoData=false;
    this.setupData=true;
  }
}
