import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-structure',
  templateUrl: './course-structure.component.html',
  styleUrls: ['./course-structure.component.scss']
})
export class CourseStructureComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
